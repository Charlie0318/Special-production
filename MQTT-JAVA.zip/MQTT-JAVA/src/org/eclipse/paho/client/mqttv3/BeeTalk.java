package org.eclipse.paho.client.mqttv3;

public class BeeTalk {
	int security;
	int policy;
	int pub_key; 
	int priv_key; 
	int version;

}
